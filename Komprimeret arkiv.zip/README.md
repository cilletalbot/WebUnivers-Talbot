Her er koderne for mit online magasin om mad på budget 
Jeg har lavet en forside hvor man kan se de nyeste og mest populære opskrifter.

Så har jeg lavet 3 artikler som alle ligger under "artikler" i navigationsbaren. 

Home button på logoet i hjørnet

Siden er ikke færdig og mangler en del indhold, dette er en prototype



